export class AutreCharge {
    id: number
    nom: string
    description: string
    prix: number
    e_charge: string
    }