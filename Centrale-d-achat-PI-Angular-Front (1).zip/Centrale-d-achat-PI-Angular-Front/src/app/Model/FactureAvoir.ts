export class FactureAvoir {
    id: number
    client: string
    reponsableclient:string
    adresseclient: string
    devise: string
    datefacture: Date
    totalttc: number
    }