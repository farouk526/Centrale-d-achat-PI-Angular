export class AppelOffre 
    {
        id: number
        nom: string
        objet: string
        description:string
        prixTotal:number
        quantiteMin: number
       
    }