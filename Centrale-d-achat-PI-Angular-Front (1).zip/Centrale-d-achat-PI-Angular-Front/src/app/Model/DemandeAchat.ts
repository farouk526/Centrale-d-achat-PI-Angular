export class DemandeAchat {
    id: number
    nom: string
    objet: string
    description: string
    quantiteMin: number
    offreType: string
    }