export class MontantPanier {
 montantTotalHT: number = 0;
 remise: number = 0;
 tva: number = 0;
montantTotalAPayer: number = 0;
}
