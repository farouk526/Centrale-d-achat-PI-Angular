export class CodePromo {
    id: number
    code: string
    remise: number
    }