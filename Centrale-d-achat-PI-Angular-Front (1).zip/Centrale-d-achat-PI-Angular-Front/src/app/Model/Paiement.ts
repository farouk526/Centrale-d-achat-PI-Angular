export class Paiement{
    id: number
  prix: number
  pays: string
  devise: string
  methode: string
  description: string
}