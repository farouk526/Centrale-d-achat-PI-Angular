export class Facture {
    id: number
    client: string
    reponsableclient: string
    adresseclient: string
    devise: string
    datefacture: Date
    fraisLivraison: number
    dateLivraison: Date
    totalttc: number
  }