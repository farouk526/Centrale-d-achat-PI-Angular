export class ItemFactureAvoir {
    id: number
    code: string
    label: string
    quantity: number
    tva: number
    priceHt: number
    montantHt: number
    montantTtc: number
  }