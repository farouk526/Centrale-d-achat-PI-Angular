import { ItemCommande } from './ItemCommande';


export class Panier {

clientcin: string;
items: ItemCommande[];
codePromo: string;

}
