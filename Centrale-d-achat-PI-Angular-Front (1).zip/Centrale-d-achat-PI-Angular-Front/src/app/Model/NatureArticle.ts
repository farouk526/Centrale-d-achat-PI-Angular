export class NatureArticle {
    id: number
    secteur: string
    description: string
    unite: string
    }