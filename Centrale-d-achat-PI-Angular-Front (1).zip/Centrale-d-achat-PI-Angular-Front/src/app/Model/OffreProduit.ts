export class OffreProduit {
    id: number
    disponibilite: boolean
    nom: string
    quantite: number   
    image: string
    prixUnitaire: number
    }