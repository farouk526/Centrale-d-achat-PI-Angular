export class OffreService {
    id: number
    nom: string
    heures: number
    disponibilite: boolean
    image: string
    prixparheure: number
  }