export const locale = {
  lang: 'de',
  data: {
    MENU: {
      HOME: 'Zuhause',
      SAMPLE: 'Stichprobe'
    }
  }
}
