# Angular Academic Project

This project was generated with [Angular CLI 13](https://github.com/angular/angular-cli).

## NOTES :

**To install dependencies use : npm install --legacy-peer-deps otherwise u will get some Compatibility problems**

YALLA :rocket:
